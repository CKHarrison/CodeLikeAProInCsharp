﻿namespace CodingKata_Stringbuilder.Interfaces
{
    public interface IDisplay
    {
        void Print(string text);
    }
}
