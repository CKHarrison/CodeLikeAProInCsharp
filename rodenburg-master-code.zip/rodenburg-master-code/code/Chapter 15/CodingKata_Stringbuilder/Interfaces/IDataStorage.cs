﻿namespace CodingKata_Stringbuilder.Interfaces
{
    public interface IDataStorage
    {
        string Read();
    }
}
