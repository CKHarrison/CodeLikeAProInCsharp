﻿using System;

namespace FlyingDutchmanAirlines.Exceptions
{
    public class CustomerNotFoundException : Exception
    {
    }
}
