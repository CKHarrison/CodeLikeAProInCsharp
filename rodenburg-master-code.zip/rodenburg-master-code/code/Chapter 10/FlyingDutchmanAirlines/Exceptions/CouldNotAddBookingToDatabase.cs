﻿namespace FlyingDutchmanAirlines.Exceptions
{
    public class CouldNotAddBookingToDatabaseException : CouldNotAddEntityToDatabaseException
    {
    }
}
