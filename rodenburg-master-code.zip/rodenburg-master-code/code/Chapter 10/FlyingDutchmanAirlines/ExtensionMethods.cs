﻿namespace FlyingDutchmanAirlines
{
    internal static class ExtensionMethods
    {
        internal static bool IsPositiveInteger(this int input)
        {
            return input >= 0;
        }
    }
}
